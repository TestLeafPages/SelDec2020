package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	
	//actionElementName
	public LoginPage enterUsername(String uName) throws InterruptedException {
		driver.findElementById("username").sendKeys(uName);
		//Thread.sleep(5000);
		return this;
	}
	
	public LoginPage enterPassword(String password) {
		
		driver.findElementById("password").sendKeys(password);
		return this;
	}
	
	public HomePage clickLoginButton() {
		
		driver.findElementByClassName("decorativeSubmit").click();
		
		return new HomePage();
	}

}
